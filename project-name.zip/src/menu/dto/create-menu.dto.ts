export class CreateMenuDto {}
