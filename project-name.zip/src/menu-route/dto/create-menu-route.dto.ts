export class CreateMenuRouteDto {}
