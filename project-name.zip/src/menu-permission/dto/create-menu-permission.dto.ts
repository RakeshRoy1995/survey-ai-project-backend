export class CreateMenuPermissionDto {}
