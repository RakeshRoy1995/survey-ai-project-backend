export class CreateRoleDto {}
